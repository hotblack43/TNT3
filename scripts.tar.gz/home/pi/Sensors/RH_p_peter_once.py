#!/usr/bin/python

# Copyright (c) 2014 Adafruit Industries
# Author: Tony DiCola

import Adafruit_DHT
import Adafruit_BMP.BMP085 as BMP085
import datetime
import time
from astropy.time import Time

# Sensor should be set to Adafruit_DHT.DHT11,
# Adafruit_DHT.DHT22, or Adafruit_DHT.AM2302.
# Sensor2 should be set to Adafruit_BMP

sensor = Adafruit_DHT.DHT22
sensor2 = BMP085.BMP085(mode=BMP085.BMP085_ULTRAHIGHRES)

# DHT sensor connected to GPIO17.
pin = 17

# Try to grab a sensor reading.  Use the read_retry method which will retry up
# to 15 times to get a sensor reading (waiting 2 seconds between each retry).
t = Time(datetime.datetime.now() , scale='utc')
humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
utc=float(("%.19f" % t.jd))
T = sensor2.read_temperature()
p = sensor2.read_pressure()

f1=open('/home/pi/Sensors/readings.dat', 'w+')
print >>f1, '%+01.19f, %+01.4f, %+01.4f, %+01.4f, %+01.4f' % (utc,temperature,T,humidity,p)
